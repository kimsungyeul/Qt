#include <QMenuBar>
#include <QMenu>
#include <QAction>
#include <QApplication>
#include <QToolBar>
#include <QDoubleSpinBox>
#include <QFontComboBox>
#include <QStatusBar>
#include <QLabel>
#include <QTextEdit>
#include <QFileDialog>
#include <QColorDialog>
#include <QFontDialog>
#include <QPrintDialog>
#include <QPrinter>
#include <QMessageBox>
#include <QDebug>

#include "qteditor.h"

#ifdef __MDI__
#include <QMdiArea>
#include <QMdiSubWindow>
#include <QHash>
#endif      /* __MDI__ */

QtEditor::QtEditor(QWidget *parent)
    : QMainWindow(parent)
{
#ifdef __MDI__
    mdiArea = new QMdiArea(this);        //  QtEditor.cpp의 생성자에 추가
    setCentralWidget(mdiArea);

//    QTextEdit *textedit = new QTextEdit(mdiArea);
//    textedit->setFontPointSize(13);
//    connect(textedit, SIGNAL(destroyed(QObject*)), SLOT(closeWindow(QObject*)));
//    mdiArea->addSubWindow(textedit);
#else
    textedit = new QTextEdit(this);
    textedit->setFontPointSize(13);
    setCentralWidget(textedit);
#endif  /* __MDI__ */

    QMenuBar *menubar = new QMenuBar(this);
    setMenuBar(menubar);

    // File Menu
    QAction *newAct = actionMethod(":/images/new.png", "&New", tr("Ctrl+N"), tr("make new file"), this, SLOT(newFile()));
    QAction *openAct = actionMethod(":/images/open.png", "&Open", tr("Ctrl+O"), tr("open a file"), this, SLOT(openFile()));
    QAction *saveAct = actionMethod(":/images/save.png", "&Save", tr("Ctrl+S"), tr("save a file"), this, SLOT(saveFile()));
    QAction *saveAsAct = actionMethod(":/images/saveas.png", "Save &As", tr("Ctrl+Shift+S"), tr("save as a file"), this, SLOT(saveAsFile()));
    QAction *printAct = actionMethod(":/images/print.png", "&Print", tr("Ctrl+P"), tr("print a file"), this, SLOT(printFile()));
    QAction *quitAct = actionMethod(":/images/quit.png", "&Quit", tr("Ctrl+Q"), tr("Quit this program"), qApp, SLOT(quit()));

    // Edit Menu
#ifdef __MDI__
    QAction *undoAct = actionMethod(":/images/undo.png", "&Undo", tr("Ctrl+Z"), tr("undo"), this, SLOT(undo()));
    QAction *redoAct = actionMethod(":/images/redo.png", "&Redo", tr("Ctrl+Shift+Z"), tr("redo"), this, SLOT(redo()));
    QAction *copyAct = actionMethod(":/images/copy.png", "&Copy", tr("Ctrl+C"), tr("copy"), this, SLOT(copy()));
    QAction *cutAct = actionMethod(":/images/cut.png", "C&ut", tr("Ctrl+X"), tr("cut"), this, SLOT(cut()));
    QAction *pasteAct = actionMethod(":/images/paste.png", "&Paste", tr("Ctrl+V"), tr("paste"), this, SLOT(paste()));
    QAction *zoomInAct = actionMethod(":/images/zoomin.png", "Zoom &In", tr("Ctrl++"), tr("zoomIn"), this, SLOT(zoomIn()));
    QAction *zoomOutAct = actionMethod(":/images/zoomout.png", "Zoom &Out", tr("Ctrl+-"), tr("zoomOut"), this, SLOT(zoomOut()));
#else
    QAction *undoAct = actionMethod(":/images/undo.png", "&Undo", tr("Ctrl+Z"), tr("undo"), textedit, SLOT(undo()));
    QAction *redoAct = actionMethod(":/images/redo.png", "&Redo", tr("Ctrl+Shift+Z"), tr("redo"), textedit, SLOT(redo()));
    QAction *copyAct = actionMethod(":/images/copy.png", "&Copy", tr("Ctrl+C"), tr("copy"), textedit, SLOT(copy()));
    QAction *cutAct = actionMethod(":/images/cut.png", "C&ut", tr("Ctrl+X"), tr("cut"), textedit, SLOT(cut()));
    QAction *pasteAct = actionMethod(":/images/paste.png", "&Paste", tr("Ctrl+V"), tr("paste"), textedit, SLOT(paste()));
    QAction *zoomInAct = actionMethod(":/images/zoomin.png", "Zoom &In", tr("Ctrl++"), tr("zoomIn"), textedit, SLOT(zoomIn()));
    QAction *zoomOutAct = actionMethod(":/images/zoomout.png", "Zoom &Out", tr("Ctrl+-"), tr("zoomOut"), textedit, SLOT(zoomOut()));
#endif              /* __MDI__ */

    // Format Menu
    QAction *colorAct = actionMethod(":/images/color.png", "&Color", tr("Ctrl+5"), tr("Change color"), this, SLOT(setColor()));
    QAction *fontAct = actionMethod(":/images/font.png", "&Font", tr("Ctrl+6"), tr("Change font"), this, SLOT(setFont()));
    QAction *alignRight = actionMethod(":/images/right.png", "&Right", tr("Ctrl+1"), tr("Align Right"), this, SLOT(alignRight()));
    QAction *alignCenter = actionMethod(":/images/center.png", "&Center", tr("Ctrl+2"), tr("Align Center"), this, SLOT(alignCenter()));
    QAction *alignLeft = actionMethod(":/images/left.png", "&Left", tr("Ctrl+3"), tr("Align Left"), this, SLOT(alignLeft()));
    QAction *alignJustify = actionMethod(":/images/justify.png", "&Justify", tr("Ctrl+4"), tr("Align Justify"), this, SLOT(alignJustify()));

    // Window Menu
#ifdef __MDI__
    QAction *cascadeAct = actionMethod(":/images/cascade.png", "&Cascade", tr("Ctrl+7"), tr("Cascade windows"), mdiArea, SLOT(cascadeSubWindows()));
    QAction *tileAct = actionMethod(":/images/tile.png", "&Tile", tr("Ctrl+8"), tr("Tile windows"), mdiArea, SLOT(tileSubWindows()));
    QAction *prevAct = actionMethod(":/images/prev.png", "&Previous Window", tr("Ctrl+<"), tr("Previous Window"), mdiArea, SLOT(activatePreviousSubWindow()));
    QAction *nextAct = actionMethod(":/images/next.png", "&Next Window", tr("Ctrl+>"), tr("Next Window"), mdiArea, SLOT(activateNextSubWindow()));
#endif

    // Help Menu
    QAction *aboutAct = actionMethod("", "&About", tr("Ctrl+0"), tr("About"), this, SLOT(about()));

    QMenu *fileMenu = menubar->addMenu("&File");
    fileMenu->addAction(newAct);
    fileMenu->addAction(openAct);
    fileMenu->addAction(saveAct);
    fileMenu->addAction(saveAsAct);
    fileMenu->addSeparator();
    fileMenu->addAction(printAct);
    fileMenu->addSeparator();
    fileMenu->addAction(quitAct);

    QMenu *editMenu = menubar->addMenu("&Edit");
    editMenu->addAction(undoAct);
    editMenu->addAction(redoAct);
    editMenu->addSeparator();
    editMenu->addAction(copyAct);
    editMenu->addAction(cutAct);
    editMenu->addAction(pasteAct);
    editMenu->addSeparator();
    editMenu->addAction(zoomInAct);
    editMenu->addAction(zoomOutAct);

    QMenu *formatMenu = menubar->addMenu("&Format");
    formatMenu->addAction(colorAct);
    formatMenu->addAction(fontAct);
    QMenu *alignMenu = formatMenu->addMenu("&Align");
    alignMenu->addAction(alignRight);
    alignMenu->addAction(alignCenter);
    alignMenu->addAction(alignLeft);
    alignMenu->addAction(alignJustify);

#ifdef __MDI__
    windowMenu = menubar->addMenu("&Window");
    windowMenu->setObjectName("WindowMenu");
    windowMenu->addAction(cascadeAct);
    windowMenu->addAction(tileAct);
    windowMenu->addSeparator();
    windowMenu->addAction(prevAct);
    windowMenu->addAction(nextAct);
    windowMenu->addSeparator();
#endif

    QMenu *helpMenu = menubar->addMenu("&About");
    helpMenu->addAction(aboutAct);

    QToolBar *fileToolBar = addToolBar("&File");
    //    fileToolBar->setToolButtonStyle(Qt::ToolButtonTextOnly);
    fileToolBar->addAction(newAct);
    fileToolBar->addAction(openAct);
    fileToolBar->addAction(saveAct);
    fileToolBar->addAction(saveAsAct);
    fileToolBar->addSeparator();
    fileToolBar->addAction(printAct);
    fileToolBar->addSeparator();
    fileToolBar->addAction(quitAct);

    QToolBar *editToolBar = addToolBar("&Edit");
//    editToolBar->setToolButtonStyle(Qt::ToolButtonTextOnly);
    editToolBar->addAction(undoAct);
    editToolBar->addAction(redoAct);
    editToolBar->addSeparator();
    editToolBar->addAction(copyAct);
    editToolBar->addAction(cutAct);
    editToolBar->addAction(pasteAct);
    editToolBar->addSeparator();
    editToolBar->addAction(zoomInAct);
    editToolBar->addAction(zoomOutAct);

#ifdef __MDI__
    QToolBar *windowToolBar = addToolBar("&Window");
    windowToolBar->addAction(cascadeAct);
    windowToolBar->addAction(tileAct);
#endif

    fontComboBox = new QFontComboBox(this);
    sizeSpinBox  = new QDoubleSpinBox(this);

#ifdef __MDI__
    connect(mdiArea, SIGNAL(subWindowActivated(QMdiSubWindow*)), this, SLOT(setCurrentWindow()));
    connect(fontComboBox, SIGNAL(currentFontChanged(QFont)), this, SLOT(setCurrentFont(QFont)));
    connect(sizeSpinBox, SIGNAL(valueChanged(double)), this, SLOT(setFontPointSize(double)));
#else
    connect(textedit, SIGNAL(cursorPositionChanged()), this, SLOT(setFormat()));
    connect(fontComboBox, SIGNAL(currentFontChanged(QFont)), textedit, SLOT(setCurrentFont(QFont)));
    connect(sizeSpinBox, SIGNAL(valueChanged(double)), textedit, SLOT(setFontPointSize(qreal)));
#endif      /* __MDI__ */
    addToolBarBreak();
    QToolBar *formatToolbar = addToolBar("&Format");
    formatToolbar->addAction(colorAct);
    formatToolbar->addAction(fontAct);
    formatToolbar->addSeparator();
    formatToolbar->addWidget(fontComboBox);
    formatToolbar->addWidget(sizeSpinBox);
    formatToolbar->addSeparator();
    formatToolbar->addAction(alignRight);
    formatToolbar->addAction(alignCenter);
    formatToolbar->addAction(alignLeft);
    formatToolbar->addAction(alignJustify);

    statusbar = statusBar();
    statusLabel = new QLabel("Qt Editor", statusbar);
    statusbar->addPermanentWidget(statusLabel);
    statusbar->showMessage("started", 1500);

    newFile();
}

QtEditor::~QtEditor()
{

}

QAction *QtEditor::actionMethod(QString icon, QString name, QString shortCut, QString toolTip, QObject* recv, const char* slot)
{
    QAction *act = new QAction(name, this);
    if(icon.length()) act->setIcon(QIcon(icon));
    if(shortCut.length()) act->setShortcut(shortCut);
    if(toolTip.length()) act->setStatusTip(toolTip);
    connect(act, SIGNAL(triggered()), recv, slot);
    return act;
}

void QtEditor::newFile()
{
    qDebug("Make New File");
#ifdef __MDI__
    QTextEdit *textedit = new QTextEdit(mdiArea);
    connect(textedit, SIGNAL(destroyed(QObject*)), textedit, SLOT(deleteLater()));
    textedit->setFontPointSize(13);
    mdiArea->addSubWindow(textedit);
    textedit->show();

    QAction *windowAct = actionMethod("", "New text", "", "", this, SLOT(selectWindow()));
    connect(textedit, SIGNAL(destroyed(QObject*)), windowAct, SLOT(deleteLater()));

    QMenu* windowMenu = findChild<QMenu *>("WindowMenu");
    windowMenu->addAction(windowAct);
    windowHash[windowAct] = textedit;
#endif  /* __MDI__ */
}

void QtEditor::openFile()
{
    qDebug("Open a File");    
    QString filename = QFileDialog::getOpenFileName(this,
                                                    "Select a file to open", ".",
                                                    "Text File(*.text *.txt *.html *.htm *.c *.cpp *.h)");
    qDebug() << filename;

    QFileInfo fileInfo(filename);
    if(fileInfo.isReadable()) {
        QFile file(filename);
        file.open(QIODevice::ReadOnly | QIODevice::Text);
        QByteArray msg = file.readAll();
        file.close();

        QTextEdit* textedit = new QTextEdit(this);
        textedit->setWindowTitle(filename);
        if(fileInfo.suffix() == "htm" || fileInfo.suffix() == "html")
            textedit->setHtml(msg);
        else
            textedit->setPlainText(msg);
        mdiArea->addSubWindow(textedit);
        textedit->show();
#ifdef __MDI__
        QAction *windowAct = actionMethod("", filename, "", filename, this, SLOT(selectWindow()));
        QMenu* windowMenu = findChild<QMenu *>("WindowMenu");
        windowMenu->addAction(windowAct);
        windowHash[windowAct] = textedit;
        connect(textedit, SIGNAL(destroyed(QObject*)), windowAct, SLOT(deleteLater()));
#endif  /* __MDI__ */
    } else {
        QMessageBox::warning(this, "Error", "Can't Read this file", QMessageBox::Ok);
    }
}

void QtEditor::saveFile()
{
    qDebug("Save a File");
#ifdef __MDI__
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
    QString filename = textedit->windowTitle();
#endif  /* __MDI__ */
    qDebug() << filename;

    if(!filename.length()) {
        filename = QFileDialog::getSaveFileName(this,
                                                "Select a file to save", ".",
                                                "Text File(*.text *.txt *.html *.htm *.c *.cpp *.h)");
        textedit->setWindowTitle(filename);
        windowHash.key(textedit)->setText(filename);
    }

    QFile file(filename);
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QFileInfo fileInfo(filename);
    if(fileInfo.isWritable()) {    // if(file->error() != QFile::OpenError) {
        QByteArray msg = textedit->toHtml( ).toUtf8( );   // QString을 QByteArray로 변환
        file.write(msg);
    } else
        QMessageBox::warning(this, "Error", "Can't Save this file", QMessageBox::Ok);
    file.close();
}

void QtEditor::saveAsFile()
{
    qDebug("Save as a File");

#ifdef __MDI__
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
    QString filename = textedit->windowTitle();
#endif  /* __MDI__ */

    filename = QFileDialog::getSaveFileName(this,
                                            "Select a file to save", ".",
                                            "Text File(*.text *.txt *.html *.htm *.c *.cpp *.h)");
#ifdef __MDI__
    textedit->setWindowTitle(filename);
    windowHash.key(textedit)->setText(filename);
    windowHash.key(textedit)->setStatusTip(filename);
#endif  /* __MDI__ */

    QFile file(filename);
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QFileInfo fileInfo(filename);
    if(fileInfo.isWritable()) {    // if(file->error() != QFile::OpenError) {
        QByteArray msg = textedit->toHtml( ).toUtf8( );   // QString을 QByteArray로 변환
        file.write(msg);
    } else
        QMessageBox::warning(this, "Error", "Can't Save this file", QMessageBox::Ok);

    file.close();
}

void QtEditor::printFile()
{
    qDebug("Print a File");

    QPrinter printer(QPrinter::HighResolution);
    printer.setFullPage(true);
    QPrintDialog printDialog(&printer, this);
    if (printDialog.exec() == QDialog::Accepted) {
#ifdef __MDI__
        QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
#endif  /* __MDI__ */
        textedit->print(&printer);
    }
}

#ifdef __MDI__
void QtEditor::undo()
{
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
    textedit->undo();
}

void QtEditor::redo()
{
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
    textedit->redo();
}

void QtEditor::copy()
{
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
    textedit->copy();
}

void QtEditor::cut()
{
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
    textedit->cut();
}

void QtEditor::paste()
{
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
    textedit->paste();
}

void QtEditor::zoomIn()
{
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
    textedit->zoomIn();
}

void QtEditor::zoomOut()
{
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
    textedit->zoomOut();
}
#endif  /* __MDI__ */

// Format Menu
void QtEditor::setColor()
{
#ifdef __MDI__
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
#endif  /* __MDI__ */
    QColor color = QColorDialog::getColor(textedit->textColor(), this);
    textedit->setTextColor(color);
    const QMetaObject* metaObject = this->metaObject();
    QString slot(SLOT(setColor()));
    slot.remove(0, 1);
    qDebug() << metaObject->indexOfSlot(slot.toLatin1());
}

void QtEditor::setFont()
{
#ifdef __MDI__
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
#endif  /* __MDI__ */
    bool ok;
    QFont font = QFontDialog::getFont(&ok, textedit->currentFont(), this);
    if(ok) textedit->setCurrentFont(font);
}

void QtEditor::setFormat()
{
#ifdef __MDI__
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
#endif  /* __MDI__ */
    fontComboBox->setFont(textedit->currentFont());
    sizeSpinBox->setValue(textedit->fontPointSize());
}

#ifdef __MDI__
void QtEditor::setCurrentWindow()
{
//    qDebug("setCurrentWindow");
    foreach (QMdiSubWindow *window, mdiArea->subWindowList()) {
        disconnect(window->widget());
    }

    QMdiSubWindow* currentWindow = mdiArea->currentSubWindow();
    if(currentWindow != nullptr) {
        QTextEdit* textedit = (QTextEdit*)currentWindow->widget();
        connect(textedit, SIGNAL(cursorPositionChanged()), this, SLOT(setFormat()));
    }
}

void QtEditor::selectWindow()
{
    QTextEdit* textedit = (QTextEdit*)windowHash[(QAction*)sender()];
    if(textedit != nullptr) {
        textedit->setFocus();
        setCurrentWindow();
    }
}

void QtEditor::setCurrentFont(QFont font)
{
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
    textedit->setCurrentFont(font);
}

void QtEditor::setFontPointSize(double size)
{
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
    textedit->setFontPointSize(size);
}
#endif  /* __MDI__ */

void QtEditor::alignRight()
{
#ifdef __MDI__
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
#endif  /* __MDI__ */
    textedit->setAlignment(Qt::AlignRight);
}

void QtEditor::alignCenter()
{
#ifdef __MDI__
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
#endif  /* __MDI__ */
    textedit->setAlignment(Qt::AlignCenter);
}

void QtEditor::alignLeft()
{
#ifdef __MDI__
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
#endif  /* __MDI__ */
    textedit->setAlignment(Qt::AlignLeft);
}

void QtEditor::alignJustify()
{
#ifdef __MDI__
    QTextEdit* textedit = (QTextEdit*)mdiArea->currentSubWindow()->widget();
#endif  /* __MDI__ */
    textedit->setAlignment(Qt::AlignJustify);
}

// Help
void QtEditor::about()
{
    QMessageBox::information(this, tr("about"), "Copyright by valentis", QMessageBox::Ok);
}
