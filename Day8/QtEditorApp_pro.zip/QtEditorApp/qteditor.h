#ifndef QTEDITOR_H
#define QTEDITOR_H

#include <QMainWindow>

#define __MDI__

class QAction;
class QLabel;
class QDoubleSpinBox;
class QFontComboBox;
#ifdef __MDI__
class QMdiArea;
#else
class QTextEdit;
#endif      /* __MDI__ */

class QtEditor : public QMainWindow
{
    Q_OBJECT

public:
    QtEditor(QWidget *parent = 0);
    ~QtEditor();

private:
    QLabel* statusLabel;
    QFontComboBox* fontComboBox;
    QDoubleSpinBox *sizeSpinBox;
    QStatusBar *statusbar;

#ifdef __MDI__
    QMdiArea* mdiArea;                         //  QtEditor.h   (QTextEdit* textedit는 삭제)
    QMenu *windowMenu;
    QHash<QAction*, QWidget*> windowHash;
#else
    QTextEdit *textedit;
#endif      /* __MDI__ */

    QAction *actionMethod(QString icon, QString name, QString shortCut, QString toolTip, QObject* recv, const char* slot);

public slots:
    // File Menu
    void newFile();
    void openFile();
    void saveFile();
    void saveAsFile();
    void printFile();

    // Edit Menu
    void undo();
    void redo();
    void copy();
    void cut();
    void paste();
    void zoomIn();
    void zoomOut();

    // Format Menu
    void setColor();
    void setFont();
    void setFormat();
    void alignRight();
    void alignCenter();
    void alignLeft();
    void alignJustify();

#ifdef __MDI__
    void setCurrentWindow();
    void selectWindow();
    void setCurrentFont(QFont);
    void setFontPointSize(double);
#endif      /* __MDI__ */

    // Help
    void about();
};

#endif // QTEDITOR_H
