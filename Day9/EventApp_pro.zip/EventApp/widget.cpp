#include "widget.h"
#include <QCloseEvent>
#include <QDebug>
#include <QApplication>

Widget::Widget(QWidget *parent)
    : QTextEdit(parent)
{
    setText(tr("Hello World"));
    resize(100, 30);
    this->installEventFilter(this);
}

Widget::~Widget()
{
}

void Widget::moveEvent(QMoveEvent*) {
    setText(QString("X : %1, Y : %2").arg(x( )).arg(y( )));
}

void Widget::closeEvent(QCloseEvent* event) {
    event->ignore( );        // accept( );
}

bool Widget::event(QEvent* e) {
    if (e->type( ) == QEvent::KeyPress) {
        QKeyEvent *ke = dynamic_cast<QKeyEvent*>(e);
        qDebug( ) << ke->text( );
        if (ke->key( ) == Qt::Key_Tab) {   // 독자적인 Tab 키 처리
            ke->accept( );
            return true;
        } else if (ke->key( ) == Qt::Key_S) {
            QApplication::postEvent(this, new QEvent(CUSTOM_EVENT));
        }
    } else if (e->type( ) >= QEvent::User) {  // Custom 이벤트 처리
        qDebug( ) << "User Event : " << e->type( );
    }
    return QObject::event(e);
}

void Widget::customEvent(QEvent *e) {
    if(e->type( ) == CUSTOM_EVENT)            // 이벤트 처리
        qDebug( ) << "customEvent : " << e->type( );
}

bool Widget::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type( ) == QEvent::KeyPress) {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent *>(event);
        qDebug("eventFilter : %c", keyEvent->key( ));
        return false;                                        /* true와 false의 차이점 확인 */
    } else {
        return QObject::eventFilter(obj, event);
    }
}

