#ifndef WIDGET_H
#define WIDGET_H

#include <QTextEdit>
#include <QEvent>

class Widget : public QTextEdit
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

protected:
    void moveEvent(QMoveEvent*) override;
    void closeEvent(QCloseEvent*) override;
    bool event(QEvent*) override;
    void customEvent(QEvent*) override;
    bool eventFilter(QObject*, QEvent*) override;

private:
    const QEvent::Type CUSTOM_EVENT = static_cast<QEvent::Type>(QEvent::User + 1);
};
#endif // WIDGET_H
