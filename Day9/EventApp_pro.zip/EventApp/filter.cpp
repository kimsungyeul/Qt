#include "filter.h"

#include <QEvent>
#include <QDebug>

Filter::Filter(QObject *parent) : QObject{parent} {
}

bool Filter::eventFilter(QObject *obj, QEvent *event) {
    if(event->type( ) == QEvent::KeyPress) {
        qDebug( ) << "Event hijacked in Filter";
        return false;
    }
    return QObject::eventFilter(obj, event);
}
